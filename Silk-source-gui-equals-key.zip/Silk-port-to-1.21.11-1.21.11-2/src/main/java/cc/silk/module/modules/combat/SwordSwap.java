package cc.silk.module.modules.combat;

import cc.silk.event.impl.player.TickEvent;
import cc.silk.mixin.MinecraftClientAccessor;
import cc.silk.module.Category;
import cc.silk.module.Module;
import cc.silk.module.setting.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.MaceItem;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class SwordSwap extends Module {

    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 10, 100, 30, 1);

    private int originalSlot = -1;
    private boolean shouldSwitchBack = false;
    private long switchTime = 0;
    private boolean attackPressedLastTick = false;

    public SwordSwap() {
        super("Sword Swap", "Switches to sword when attacking with any non-axe/mace item", Category.COMBAT);
        addSettings(switchDelay);
    }

    @EventHandler
    public void onTick(TickEvent event) {
        if (isNull()) return;

        if (shouldSwitchBack && System.currentTimeMillis() - switchTime >= switchDelay.getValue()) {
            if (originalSlot != -1) {
                mc.player.getInventory().setSelectedSlot(originalSlot);
                originalSlot = -1;
            }
            shouldSwitchBack = false;
        }

        boolean attackPressed = mc.options.attackKey.isPressed();

        if (attackPressed && !attackPressedLastTick) {
            var heldItem = mc.player.getMainHandStack().getItem();
            boolean isAxe = heldItem instanceof AxeItem;
            boolean isMace = heldItem instanceof MaceItem;
            boolean isSword = mc.player.getMainHandStack().isIn(ItemTags.SWORDS);

            if (!isAxe && !isMace && !isSword) {
                HitResult hitResult = mc.crosshairTarget;
                if (hitResult != null && hitResult.getType() == HitResult.Type.ENTITY) {
                    var entity = ((EntityHitResult) hitResult).getEntity();
                    if (entity != null && !(entity instanceof EndCrystalEntity)) {
                        int swordSlot = findSwordSlot();
                        if (swordSlot != -1) {
                            originalSlot = mc.player.getInventory().getSelectedSlot();
                            mc.player.getInventory().setSelectedSlot(swordSlot);
                            ((MinecraftClientAccessor) mc).invokeDoAttack();
                            switchTime = System.currentTimeMillis();
                            shouldSwitchBack = true;
                        }
                    }
                }
            }
        }

        attackPressedLastTick = attackPressed;
    }

    private int findSwordSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isIn(ItemTags.SWORDS)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void onDisable() {
        if (originalSlot != -1) {
            mc.player.getInventory().setSelectedSlot(originalSlot);
            originalSlot = -1;
        }
        shouldSwitchBack = false;
        attackPressedLastTick = false;
    }
}